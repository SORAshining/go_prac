// Package sameuser provides utilities for checking users of a local connection.
// Only works in Linux.
package sameuser
